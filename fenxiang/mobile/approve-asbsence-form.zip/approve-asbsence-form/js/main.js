jQuery(function($){
    var XK=window.XK,
        util=XK.util;
	var absWrap=$('.abs-wrap'),
        leaveTableEl=$('.leave',absWrap),
		tbodyRowTpl=$('.tbody-row',absWrap),
		cateSelEl=$('.cate-wrapper',absWrap).find('.cate'),
		timeSpanEditEl=$('.time-span-edit',absWrap);
	var leaveSummaryWrap=$('.leave-summary',absWrap),
		numTotalEl=$('.num',leaveSummaryWrap);
    var sysName=util.sysDetector();
	var tbodyRowHtml='<tbody class="tbody-row">'+
        '<tr>'+
            '<td class="cate-wrapper">'+
                '<select name="cate" class="sel-pub cate">'+
                    '<option value="0" selected="selected"></option>'+
                    '<option value="1">事假</option>'+
                    '<option value="2">病假</option>'+
                    '<option value="3">调休</option>'+
                    '<option value="4">年休假</option>'+
                    '<option value="5">婚假</option>'+
                    '<option value="6">生育假</option>'+
                    '<option value="7">丧假</option>'+
                    '<option value="8">加班</option>'+
                    '<option value="9">外勤</option>'+
                    '<option value="10">出差</option>'+
                    '<option value="11">其他</option>'+
                '</select>'+
            '</td>'+
            '<td class="start-date-wrapper">'+
                '<input type="text" class="inp-text" placeholder="选择日期" readonly="readonly" />'+
            '</td>'+
            '<td class="end-date-wrapper">'+
                '<input type="text" class="inp-text" placeholder="选择日期" readonly="readonly" />'+
            '</td>'+
            '<td class="time-span"><input type="number" class="text-edit time-span-edit" maxlength="12" /></td>'+
        '</tr>'+
    '</tbody>';
    var initLeave=function(){
        var initLeaveData;
        var blankLeaveData=(function(){
            return {
                "cate":0,
                "startTime":"",
                "endTime":"",
                "timeSpan":""
            };
        }());
        if(sysName=="android"){
            initLeaveData=util.externalExecute('initLeaveData');
        }else{
            initLeaveData="";
        }

        if(initLeaveData.length==0){
            initLeaveData=[blankLeaveData,blankLeaveData,blankLeaveData];
        }else{
            initLeaveData=JSON.parse(initLeaveData);
            initLeaveData.push(blankLeaveData);
        }
        _.each(initLeaveData,function(itemData){
            var cateEl,
                startDateEl,
                endDateEl,
                timeSpanEl;
            var itemEl=$(tbodyRowHtml);
            itemEl.appendTo(leaveTableEl);
            cateEl=$('.cate-wrapper select',itemEl);
            startDateEl=$('.start-date-wrapper input',itemEl);
            endDateEl= $('.end-date-wrapper input',itemEl);
            timeSpanEl= $('.time-span input',itemEl);
            //填充数据
            cateEl.val(itemData.cate);
            startDateEl.val(itemData.startTime);
            endDateEl.val(itemData.endTime);
            timeSpanEl.val(itemData.timeSpan);
        });
    };
    //android需要初始化初始化数据填充表单,ios会保留上次的页面
    initLeave();
	//cateSelEl.unbind('change');
	absWrap.on('change','select.cate:last',function(){
		if($(this).val() !== 0){
            leaveTableEl.append(tbodyRowHtml);
		}
	});
	
	//请假单效果
	absWrap.on('change', 'input.time-span-edit', function () {
		var timeSpanEl = $('input.time-span-edit', absWrap),
			totalTime = 0;
		timeSpanEl.each(function () {
			var meEl = $(this),
				v = $.trim(meEl.val());
			if (v.length > 0) {
				v = parseFloat(v);
				if (!isNaN(v)) {
					v = parseFloat(v.toFixed(2));
					totalTime += v;
					meEl.val(v);
				} else {
					meEl.val('0');
				}
			}
		});
		numTotalEl.text(totalTime);
	});

    //日历组件调用
    absWrap.on('click','.start-date-wrapper input,.end-date-wrapper input',function(evt){
        var meEl=$(this),
            wEl=meEl.closest('td'),
            labelText;
        $('.start-date-wrapper input,.end-date-wrapper input',absWrap).removeClass('state-input-focus');
        meEl.addClass('state-input-focus');
        if(wEl.hasClass('start-date-wrapper')){
            labelText="start";
        }else if(wEl.hasClass('end-date-wrapper')){
            labelText="end";
        }
        util.externalExecute("showCalendar",labelText);
    });
    //日历选择完毕后的回调注册
    util.regInterceptor('calendarCallback',function(dateStr){
        var currentInputEl=$('.state-input-focus',absWrap);
        currentInputEl.val(dateStr).removeClass('state-input-focus');
    });
    //点击确定将参数传给系统
    util.regInterceptor('leaveSubmitCallback',function(){
        var formData=[],
            saveData=[],
            isPassed=true;
        $('.leave .tbody-row tr',absWrap).each(function(){
            var cateSelectEl=$('.cate-wrapper select',this);
            var cate=parseInt(cateSelectEl.val()),
                startTime= $.trim($('.start-date-wrapper input',this).val()),
                endTime= $.trim($('.end-date-wrapper input',this).val()),
                timeSpan= $.trim($('.time-span input',this).val());
            formData.push({
                "cate":cate,
                "reasonTypeDesc":$('option[value="'+cate+'"]',cateSelectEl).text(),
                "startTime":startTime,
                "endTime":endTime,
                "timeSpan":timeSpan
            });
        });
        //过滤掉全空的数据
        formData= _.reject(formData,function(itemData){
            return itemData.cate==0&&itemData.startTime.length==0&&itemData.endTime.length==0&&itemData.timeSpan.length==0;
        });
        //数据验证
        if(formData.length==0){
            isPassed=false;
            util.alert("请填写请假单");
            return isPassed;
        }
        _.some(formData,function(itemData){
            if(itemData.cate==0){
                isPassed=false;
                util.alert("请选择请假事项");
                return true;
            }
            if(itemData.startTime.length==0){
                isPassed=false;
                util.alert("请填写开始日期");
                return true;
            }
            if(itemData.endTime.length==0){
                isPassed=false;
                util.alert("请填写结束日期");
                return true;
            }
            if(itemData.timeSpan.length==0){
                isPassed=false;
                util.alert("请填写请假小时数");
                return true;
            }
            //判断结束时间大于开始时间
            if(moment(itemData.endTime, "YYYY-MM-DD HH:mm").isBefore(moment(itemData.startTime, "YYYY-MM-DD HH:mm"))){
                isPassed=false;
                util.alert("结束时间需要大于开始时间");
                return true;
            }
        });
        //整合数据
        _.each(formData,function(itemData){
            var startTime=itemData.startTime.split(' '),
                endTime=itemData.endTime.split(' ');
            saveData.push({
                "reasonType":itemData.cate,
                "reasonTypeDesc":itemData.reasonTypeDesc,
                "startDate":startTime[0],
                "stopDate":endTime[0],
                "startTime":startTime[1],
                "stopTime":endTime[1],
                "beginTime":moment(itemData.startTime, "YYYY-MM-DD HH:mm").unix(),
                "endTime":moment(itemData.endTime, "YYYY-MM-DD HH:mm"),
                "hours":itemData.timeSpan
            });
        });
        if(!isPassed){
            return isPassed;
        }else{
            //这里传给后台数据
            util.externalExecute('saveLeaveData',JSON.stringify(saveData));
            return true;
        }
    });
	
	//报销单
	var expWrap=$('.exp-wrap'),
		baoxiaoEl = $('.baoxiao', expWrap),
		baoxiaoRowTpl = $('.baoxiao-row-tpl', expWrap).html(),
		baoxiaoSummaryEl = $('.baoxiao-summary', expWrap),
		baoxiaoUpperEl = $('.upper-text', baoxiaoSummaryEl),
		baoxiaoTjEl = $('.num-text', baoxiaoSummaryEl);
	/**
	 * 动态生成一条报销单
	 * @param {[type]} rowTpl [description]
	 */
	var addBaoxiaoRow = function (rowTpl) {
		var rowEl = $(rowTpl || baoxiaoRowTpl);
		rowEl.appendTo(baoxiaoEl);
		//清空input change事件
		$('input', baoxiaoEl).unbind('change');
		$('input', rowEl).change(function () {
			addBaoxiaoRow();
		});
		return rowEl;
	};
	//报销单统计
	baoxiaoEl.on('change', 'input.amount', function () {
		var amountEl = $('input.amount', baoxiaoEl),
			totalAmount = 0;
		amountEl.each(function () {
			var meEl = $(this),
				v = $.trim(meEl.val());
			if (v.length > 0) {
				v = parseFloat(v);
				if (!isNaN(v)) {
					v = parseFloat(v.toFixed(2));
					totalAmount += v;
					meEl.val(v.toFixed(2));
				} else {
					meEl.val('非有效数字');
				}
			}
		});
		//截取小数点后两位
		totalAmount=parseFloat(totalAmount.toFixed(2));
		baoxiaoUpperEl.text(util.digitUppercase(totalAmount));
		baoxiaoTjEl.text(totalAmount.toFixed(2));

	});
	
	/**
	 * 初始化报销单
	 */
    var initBaoxiao=function(){
        var initData;
        var blankData=(function(){
            return {
                "cate":"",
                "amount":"",
                "mark":""
            };
        }());
        if(sysName=="android"){
            initData=util.externalExecute('initBaoxiaoData');
        }else{
            initData="";
        }

        if(initData.length==0){
            initData=[blankData,blankData,blankData];
        }else{
            initData=JSON.parse(initData);
            initData.push(blankData);
        }
        _.each(initData,function(itemData){
            var cateEl,
                amountEl,
                markEl;
            var itemEl=$(baoxiaoRowTpl);

            itemEl.appendTo(baoxiaoEl);
            cateEl=$('.cate-wrapper input',itemEl);
            amountEl=$('.amount-wrapper input',itemEl);
            markEl=$('.mark-wrapper input',itemEl);
            //填充数据
            cateEl.val(itemData.cate);
            amountEl.val(itemData.amount);
            markEl.val(itemData.mark);
        });
    };
    //android需要初始化初始化数据填充表单,ios会保留上次的页面
    initBaoxiao();
	
	//报销单 点击确定将参数传给系统
    util.regInterceptor('baoxiaoSubmitCallback',function(){
        var formData=[],
            isPassed=true;
        $('.baoxiao tbody tr',expWrap).each(function(){
            var cate= _.str.trim($('.cate-wrapper input',this).val()),
                amount= _.str.trim($('.amount-wrapper input',this).val()),
                mark=_.str.trim($('.mark-wrapper input',this).val());
            formData.push({
                "title":cate,
                "amount":amount,
                "remark":mark
            });
        });
        //过滤掉全空的数据
        formData= _.reject(formData,function(itemData){
            return itemData.title.length==0&&itemData.amount.length==0&&itemData.remark.length==0;
        });
        //数据验证
        if(formData.length==0){
            isPassed=false;
            util.alert("请填写报销单");
            return isPassed;
        }
        _.some(formData,function(itemData){
            if(itemData.title.length==0){
                isPassed=false;
                util.alert("请填写报销项名称");
                return true;
            }
            if(itemData.amount.length==0){
                isPassed=false;
                util.alert("请填写报销金额");
                return true;
            }
            if(isNaN(parseFloat(itemData.amount))){
                util.alert("请输入有效的报销金额");
                return true;
            }
        });
        if(!isPassed){
            return isPassed;
        }else{
            //这里传给后台数据
            util.externalExecute('saveBaoxiaoData',JSON.stringify(formData));
            return true;
        }
    });
});